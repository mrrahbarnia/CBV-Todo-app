from django.test import TestCase
from ..forms import TodoForm

class TestForm(TestCase):

    def test_todo_form_with_validate_data(self):
        form = TodoForm(data={
            'title':'hello'
        })
        self.assertTrue(form.is_valid())

    def test_todo_form_with_no_data(self):
        form = TodoForm(data={})
        self.assertFalse(form.is_valid())