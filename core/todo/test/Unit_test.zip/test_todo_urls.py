from django.test import SimpleTestCase
from django.urls import reverse,resolve
from ..views import (
    CreateTodoView,
    DeleteTodoView,
    UpdateTodoView
)

class TestUrl(SimpleTestCase):

    def test_todo_create_url_resolve(self):
        url = reverse('todo-create')
        self.assertEqual(resolve(url).func.view_class,CreateTodoView)

    def test_todo_delete_url_resolve(self):
        url = reverse('todo-delete',kwargs={'pk':1})
        self.assertEqual(resolve(url).func.view_class,DeleteTodoView)

    def test_todo_update_url_resolve(self):
        url = reverse('todo-edit',kwargs={'pk':1})
        self.assertEqual(resolve(url).func.view_class,UpdateTodoView)
