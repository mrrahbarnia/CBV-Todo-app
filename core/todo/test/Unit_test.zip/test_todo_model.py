from django.test import TestCase
from django.contrib.auth.models import User

from ..models import Todo

class TestTodoModel(TestCase):

    def setUp(self):
        self.user = User.objects.create(username = 'test',password = 'T13431344')

    def test_create_todo_with_valid_data(self):
        task = Todo.objects.create(
            user = self.user,
            task = 'test'
        )
        self.assertEqual(task.task,'test')
        self.assertTrue(Todo.objects.filter(pk=task.id).exists())