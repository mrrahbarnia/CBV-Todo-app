from django.test import TestCase,Client
from django.contrib.auth.models import User
from django.urls import reverse

class TestTodoView(TestCase):

    def setUp(self):
        self.user = User.objects.create(username = 'test' , password = 'T13431344')
        self.client = Client()
    
    def test_todo_createview_response_with_annonymous_user(self):
        url = reverse('todo-create')
        response = self.client.get(url)
        self.assertEqual(response.status_code,302)

    def test_todo_createview_response_with_loggedin_user(self):
        self.client.force_login(user = self.user)
        url = reverse('todo-create')
        response = self.client.get(url)
        self.assertEqual(response.status_code,200)
        self.assertTemplateUsed(response,template_name='todo/todo_list.html')
